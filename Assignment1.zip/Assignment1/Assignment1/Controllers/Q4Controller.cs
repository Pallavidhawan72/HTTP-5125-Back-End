﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assignment1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Q4Controller : ControllerBase
    {
        /// <summary>
        /// Receives an HTTP POST request and provides a message.
        /// </summary>
        /// <returns>
        /// It returns a message like "Who's there?"
        /// </returns>
        /// <example>
        /// POST api/q4/knockknock -> Who's there?
        /// </example>
        [HttpPost(template: "knockknock")]
        public string knockknock()
        {
            return ("Who's there?");
        }
    }
}
