﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assignment1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Q3Controller : ControllerBase
    {
        // <summary>
        /// It calculates the cube of a given number
        /// </summary>
        /// <param name="num">The number which we want to be cubed</param>
        /// <returns>
        /// It returns the cube of the entered number
        /// </returns>
        /// <example>
        /// GET api/q3/cube/2 -> 8
        /// GET api/q3/cube/-5 -> -125
        /// </example>
        [HttpGet(template: "cube/{num}")]
        public int Cube(int num)
        {
            int cubenum = num * num * num;
            return cubenum;
        }
    }
}
